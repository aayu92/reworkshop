document.addEventListener("DOMContentLoaded", function () {
    // Smooth Animations
    gsap.from(".hero h1", { duration: 1, y: -50, opacity: 0, ease: "bounce" });
    gsap.from(".hero p", { duration: 1, opacity: 0, delay: 0.5 });
    gsap.from(".btn", { duration: 1, opacity: 0, scale: 0.5, delay: 1, ease: "elastic" });

    // Scroll to Products when clicking "View Products"
    const viewProductsBtn = document.querySelector(".btn");
    if (viewProductsBtn) {
        viewProductsBtn.addEventListener("click", function () {
            document.querySelector(".products").scrollIntoView({ behavior: "smooth" });
        });
    }
});

  const items = document.querySelectorAll('.carousel-item');
  let index = 0;

  setInterval(() => {
    items[index].classList.remove('active');
    index = (index + 1) % items.length;
    items[index].classList.add('active');
  }, 3000); // Change every 3 seconds


