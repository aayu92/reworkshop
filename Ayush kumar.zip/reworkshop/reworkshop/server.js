const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));






const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',             // or your MySQL username
    password: 'rohan@123',             // or your MySQL password
    database: 'shop_db'
});

db.connect((err) => {
    if (err) {
        console.error('DB connection error:', err);
        return;
    }
    console.log('✅ Connected to MySQL database');
});

// Submit feedback
app.post('/api/feedback', (req, res) => {
    const { name, email, message } = req.body;
    const sql = `INSERT INTO customer_feedback (name, email, message) VALUES (?, ?, ?)`;
    db.query(sql, [name, email, message], (err, result) => {
        if (err) return res.status(500).send('Error saving feedback');
        res.send('Feedback submitted successfully');
    });
});

// Admin view feedback
app.get('/api/feedback', (req, res) => {
    const sql = `SELECT * FROM customer_feedback ORDER BY submitted_at DESC`;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send('Error fetching feedback');
        res.json(results);
    });
});
// Simple admin login check (not recommended for production)
app.post('/api/admin/login', (req, res) => {
    const { adminID, adminPassword } = req.body;
    if (adminID === 'admin' && adminPassword === 'password123') {
        res.json({ success: true });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
});

// ----------- CUSTOMER ORDERS -----------

// Submit order
app.post('/api/orders', (req, res) => {
    const { email, customer_name, quantity, product_name } = req.body;
    const sql = `INSERT INTO customer_orders (email, customer_name, quantity, product_name) VALUES (?, ?, ?, ?)`;
    db.query(sql, [email, customer_name, quantity, product_name], (err, result) => {
      if (err) return res.status(500).send('Error saving order');
      res.send('Order submitted successfully');
    });
  });
  

// Admin view orders
app.get('/api/orders', (req, res) => {
    const sql = `SELECT * FROM customer_orders ORDER BY id DESC`;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send('Error fetching orders');
        res.json(results);
    });
});

// order status
// Check order status by email or order ID
app.get('/api/order-status', (req, res) => {
    const query = req.query.query;
  
    const sql = `SELECT status FROM customer_orders WHERE email = ? OR id = ? LIMIT 1`;
  
    db.query(sql, [query, query], (err, results) => {
      if (err) {
        console.error("Error fetching order status:", err);
        return res.status(500).json({ error: 'Server error' });
      }
  
      if (results.length > 0) {
        res.json({ status: results[0].status });
      } else {
        res.json({ status: null }); // No order found
      }
    });
  });
  
  // Confirm order
app.put('/api/orders/:id/confirm', (req, res) => {
    const orderId = req.params.id;
  
    const sql = `UPDATE customer_orders SET status = 'Confirmed' WHERE id = ?`;
    db.query(sql, [orderId], (err, result) => {
      if (err) {
        console.error("Error confirming order:", err);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json({ success: true });
    });
  });
  
// Confirm order (called from admin)
app.put('/api/orders/:id/confirm', (req, res) => {
    const orderId = req.params.id;
  
    const sql = `UPDATE customer_orders SET status = 'Confirmed' WHERE id = ?`;
  
    db.query(sql, [orderId], (err, result) => {
      if (err) {
        console.error("Error confirming order:", err);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json({ success: true });
    });
  });

  // Delete order admin
app.delete('/api/orders/:id', (req, res) => {
    const orderId = req.params.id;
  
    const sql = `DELETE FROM customer_orders WHERE id = ?`;
  
    db.query(sql, [orderId], (err, result) => {
      if (err) {
        console.error("Error deleting order:", err);
        return res.status(500).json({ error: 'Database error' });
      }
  
      res.json({ success: true });
    });
  });
  
  
// Start Server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

